﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Financeiro;
using TelasTCC.DB.Login;

namespace TelasTCC
{
    public partial class frmModFinanceiro : Form
    {
        public frmModFinanceiro()
        {
            InitializeComponent();
            ListarFolhaPagamento();
        }
        
        private void btnCaixa_Click(object sender, EventArgs e)
        {
            /*gbCaixa.Visible = true;
            gbCaixa.Enabled = true;
            cbDia.Checked = true;
            dataGridPagamento.Visible = false;*/
        }

        private void btnVendasCard_Click(object sender, EventArgs e)
        {
            lblCartao.Text = "Vendas em cartão: " + "56";
            lblRecCartao.Text = "Recebido em cartão: " + "R$ 387,90";
            lblDinheiro.Text = "Vendas em dinheiro: " + "12";
            lblRecDinheiro.Text = "Recebido em dinheiro" + "R$ 120,50";
            lblTotal.Text = "Valor total do " + "dia: " + "R$ 508,40";
        }
        private void ListarFolhaPagamento()
        {
            FinanceiroDTO dto = new FinanceiroDTO();

            FinanceiroBusiness business = new FinanceiroBusiness();
            List<FinanceiroDTO> lista = business.Listar();

            dgvPagamento.AutoGenerateColumns = false;
            dgvPagamento.DataSource = lista;
        }

        private void btnPeriodo_Click(object sender, EventArgs e)
        {
            if (radDia.Checked == true || radMes.Checked == true || radAno.Checked == true)
            {
                
                string inicio, fim = string.Empty;

                if (radDia.Checked == true)
                {
                    string script = "SELECT COUNT(`idVendas`) as qtdeVendas FROM `venda` WHERE `dataVenda` = CURRENT_DATE()";
                    //total
                    string cartao = " as qtdeVendas FROM `venda` WHERE `dataVenda` = CURRENT_DATE() AND `FormaPagamento_idFormaPagamento` BETWEEN '2' AND '4'";
                    //cartao
                    string dinheiro = "as qtdeVendas FROM `venda` WHERE `dataVenda` = CURRENT_DATE() AND `FormaPagamento_idFormaPagamento` = '1'";
                    //dinheiro
                    LabelText(script, "SELECT COUNT(`idVendas`) " + cartao, "SELECT SUM(`valorVenda`) " + cartao, "SELECT COUNT(`idVendas`) " + dinheiro, "SELECT SUM(`valorVenda`) " + dinheiro);
                }
                else if (radMes.Checked == true)
                {
                    FinanceiroDatabase database = new FinanceiroDatabase();
                    string data = database.ListarDataAtual("SELECT LEFT(NOW(), 8) AS agora");

                    inicio = data + "01";
                    fim = data + "31"; //chec para tratar o ultimo dia dos meses
                    
                    InicioFim(inicio, fim);
                }
                else if(radAno.Checked == true)
                {
                    FinanceiroDatabase database = new FinanceiroDatabase();
                    string data = database.ListarDataAtual("SELECT LEFT(NOW(), 5) AS agora");

                    inicio = data + "01-01";
                    fim = data + "12-31";
                    
                    InicioFim(inicio, fim);
                }
            }
            else
            {
                MessageBox.Show("Selecione o período.");
            }
        }

        public void InicioFim(string inicio, string fim)
        {
            string script = "SELECT COUNT(`idVendas`) as qtdeVendas FROM `venda` WHERE `dataVenda` BETWEEN '" + inicio + "' AND '" + fim + "'";

            string cartao = "as qtdeVendas FROM `venda` WHERE `dataVenda` BETWEEN '" + inicio + "' AND '" + fim + "' AND `FormaPagamento_idFormaPagamento` BETWEEN '2' AND '4'";

            string dinheiro = "as qtdeVendas FROM `venda` WHERE `dataVenda` BETWEEN '" + inicio + "' AND '" + fim + "' AND `FormaPagamento_idFormaPagamento` = '1'";

            LabelText(script, "SELECT COUNT(`idVendas`) " + cartao, "SELECT SUM(`valorVenda`) " + cartao, "SELECT COUNT(`idVendas`) " + dinheiro, "SELECT SUM(`valorVenda`) " + dinheiro);
        }

        public void LabelText(string scriptTotal, string scriptCartao, string scriptValorCartao, string dinheiro, string scriptValorDinheiro)
        {
            FinanceiroBusiness business = new FinanceiroBusiness();

            lblTotal.Text = "Total de vendas do período: " + business.ListarTotalVendas(scriptTotal);
            lblCartao.Text = "Vendas cartão: " + business.ListarTotalVendas(scriptCartao);
            lblRecCartao.Text = "Recebido em cartão: " + business.ListarTotalVendas(scriptValorCartao);
            lblDinheiro.Text = "Vendas dinheiro: " + business.ListarTotalVendas(dinheiro);
            lblRecDinheiro.Text = "Recebido em dinheiro: " + business.ListarTotalVendas(scriptValorDinheiro);
        }
    }
}
