﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.FinalizarCompra;
using TelasTCC.DB.Login;

namespace TelasTCC
{
    public partial class frmFinalizarCompra : Form
    {
        public frmFinalizarCompra()
        {
            InitializeComponent();
            ListarInfoUsuario();
            ListarValoresFinais();
        }

        private void btnCorrigir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Apagar ", "Apagar item", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {

            }
                this.dgvPedidos.CurrentRow.Cells[0].Value.ToString();
        }

        public void ListarValoresFinais()
        {
            FinalizarCompraDatabase database = new FinalizarCompraDatabase();
            string idCompra = database.ListarPedido();

            FinalizarCompraBusiness business = new FinalizarCompraBusiness();
            List<FinalizarCompraDTO> lista = business.Listar(idCompra);

            dgvPedidos.AutoGenerateColumns = false;
            dgvPedidos.DataSource = lista;

            string valorFinal = database.ValorFinal(idCompra);

            lblPrecoFinal.Text = "Valor final: " + valorFinal + " reais.";
        }

        private void btnFinalizar_Click(object sender, EventArgs e)
        {
            if (radCredito.Checked == false && radDebito.Checked == false && radValeRefeicao.Checked == false && txtValorEntregue.Text == string.Empty)
            {
                MessageBox.Show("Selecione uma forma de pagamento.");
            }
            else
            {
                if ((radCredito.Checked == true || radDebito.Checked == true || radValeRefeicao.Checked == true) && txtValorEntregue.Text != string.Empty)
                {
                    MessageBox.Show("Selecione apenas uma forma de pagamento.");
                }
                else if ((radCredito.Checked == true || radDebito.Checked == true || radValeRefeicao.Checked == true) || txtValorEntregue.Text != string.Empty)
                {
                    FinalizarCompraDTO dto = new FinalizarCompraDTO();

                    FinalizarCompraDatabase database = new FinalizarCompraDatabase();
                    dto.IdPedido = database.ListarPedido();
                    dto.ValorFinal = database.ValorFinal(dto.IdPedido);

                    string fail = string.Empty;

                    if (radCredito.Checked == true) { dto.FormaPagamento = "2"; dto.Bandeira = cbBandeira.Text; }
                    else if (radDebito.Checked == true) { dto.FormaPagamento = "3"; dto.Bandeira = cbBandeira.Text; }
                    else if (radValeRefeicao.Checked == true) { dto.FormaPagamento = "4"; dto.Bandeira = cbBandeira.Text; }
                    else if (txtValorEntregue.Text != string.Empty) {
                        dto.FormaPagamento = "1";
                        try
                        {
                            if (float.Parse(txtValorEntregue.Text) >= float.Parse(dto.ValorFinal))
                            {
                                MessageBox.Show("Troco: " + (float.Parse(txtValorEntregue.Text) - float.Parse(dto.ValorFinal)));
                                lblTroco.Text = "Troco: " + (float.Parse(txtValorEntregue.Text) - float.Parse(dto.ValorFinal));
                                fail = "ok";
                            }
                            else if (float.Parse(txtValorEntregue.Text) < float.Parse(dto.ValorFinal))
                            {
                                MessageBox.Show("O valor recebido é menor que o valor da compra.");
                                txtValorEntregue.Clear();
                                txtValorEntregue.Focus();
                                fail = "fail";
                            }
                        }
                        catch (Exception)
                        {
                            MessageBox.Show("O valor digitado é invalido.");
                            txtValorEntregue.Clear();
                            txtValorEntregue.Focus();
                            fail = "fail";
                        }
                    }

                    if (fail != "fail")
                    {
                        if (dto.Bandeira != string.Empty)
                        {
                            FinalizarCompraBusiness business = new FinalizarCompraBusiness();
                            business.SalvarComBandeira(dto);

                            MessageBox.Show("Venda finalizada com sucesso.");

                            this.Close();
                        }
                        else
                        {
                            FinalizarCompraBusiness business = new FinalizarCompraBusiness();
                            business.SalvarSemBandeira(dto);

                            MessageBox.Show("Venda finalizada com sucesso.");

                            this.Close();
                        }
                    }
                }
            }
        }

        private void txtValorEntregue_TextChanged(object sender, EventArgs e)
        {
            if(radCredito.Checked == true){radCredito.Checked = false;}
            if (radDebito.Checked == true) { radDebito.Checked = false; }
            if (radValeRefeicao.Checked == true) { radValeRefeicao.Checked = false; }
            cbBandeira.Text = string.Empty;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Apagar "+ this.dgvPedidos.CurrentRow.Cells[1].Value.ToString(), "Apagar item", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                FinalizarCompraBusiness business = new FinalizarCompraBusiness();
                business.Excluir(this.dgvPedidos.CurrentRow.Cells[0].Value.ToString());

                // não listar quando a dgv ficar vazia
                ListarValoresFinais();
            }
        }

        private void brnEnviar_Click(object sender, EventArgs e)
        {
            if (txtAddQuantidade.Text != string.Empty)
            {
                FinalizarCompraDTO dto = new FinalizarCompraDTO();
                dto.Id = lblId.Text;
                dto.ItemQuantidade = txtAddQuantidade.Text;
                
                
                //try catch ou outra forma de tratar o erro de inserção de texto
                dto.ItemPreco = "" + (float.Parse(lblPreco.Text) * float.Parse(txtAddQuantidade.Text));
                
                FinalizarCompraBusiness business = new FinalizarCompraBusiness();
                business.Editar(dto);
                MessageBox.Show("Atualizado com sucesso!");
                ListarValoresFinais();
            }
            else
            {
                MessageBox.Show("Informe a nova quantidade!");
                txtAddQuantidade.Focus();
            }
            
        }

        private void btnEditar_Click(object sender, EventArgs e)
        { 
            txtAddQuantidade.Text = this.dgvPedidos.CurrentRow.Cells[2].Value.ToString();
            lblId.Text = this.dgvPedidos.CurrentRow.Cells[0].Value.ToString();
            
            
            lblPreco.Text = (float.Parse(this.dgvPedidos.CurrentRow.Cells[3].Value.ToString()) / float.Parse(this.dgvPedidos.CurrentRow.Cells[2].Value.ToString())).ToString();
        }

        public void ListarInfoUsuario()
        {
            Funcao clieneteInfo = new Funcao();
            string info = clieneteInfo.GetTellCliente();

            if (info != string.Empty)
            {
                FinalizarCompraDatabase database = new FinalizarCompraDatabase();
                lblCliente.Text = database.InfoCliente("Nome", info);
                lblTelefone.Text = database.InfoCliente("Telefone", info);

                string endereco = database.InfoCliente("Endereco_idEndereco", info);
                lblEndereco.Text = database.EnderecoCliente(endereco); 

                clieneteInfo.SetTellCliente(string.Empty);
            }
            else
            {
                lblCliente.Visible = false;
                lblEndereco.Visible = false;
                lblTelefone.Visible = false;
            }
        }
    }
}
