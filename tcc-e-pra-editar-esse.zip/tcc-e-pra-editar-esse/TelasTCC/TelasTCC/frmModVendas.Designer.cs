﻿namespace TelasTCC
{
    partial class frmModVendas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtTellCliente = new System.Windows.Forms.TextBox();
            this.btnFazerEntrega = new System.Windows.Forms.Button();
            this.lblSabor = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSalao = new System.Windows.Forms.Button();
            this.radPizzaria = new System.Windows.Forms.RadioButton();
            this.radRestaurante = new System.Windows.Forms.RadioButton();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtTellCliente);
            this.groupBox3.Controls.Add(this.btnFazerEntrega);
            this.groupBox3.Controls.Add(this.lblSabor);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.groupBox3.Location = new System.Drawing.Point(22, 157);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(454, 100);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Entrega";
            // 
            // txtTellCliente
            // 
            this.txtTellCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtTellCliente.Location = new System.Drawing.Point(169, 43);
            this.txtTellCliente.Name = "txtTellCliente";
            this.txtTellCliente.Size = new System.Drawing.Size(112, 26);
            this.txtTellCliente.TabIndex = 0;
            // 
            // btnFazerEntrega
            // 
            this.btnFazerEntrega.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.btnFazerEntrega.Location = new System.Drawing.Point(297, 36);
            this.btnFazerEntrega.Name = "btnFazerEntrega";
            this.btnFazerEntrega.Size = new System.Drawing.Size(144, 39);
            this.btnFazerEntrega.TabIndex = 1;
            this.btnFazerEntrega.Text = "Fazer entrega";
            this.btnFazerEntrega.UseVisualStyleBackColor = true;
            this.btnFazerEntrega.Click += new System.EventHandler(this.btnFazerEntrega_Click);
            // 
            // lblSabor
            // 
            this.lblSabor.AutoSize = true;
            this.lblSabor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSabor.Location = new System.Drawing.Point(20, 49);
            this.lblSabor.Name = "lblSabor";
            this.lblSabor.Size = new System.Drawing.Size(143, 20);
            this.lblSabor.TabIndex = 1;
            this.lblSabor.Text = "Telefone do cliente";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnSalao);
            this.groupBox2.Controls.Add(this.radPizzaria);
            this.groupBox2.Controls.Add(this.radRestaurante);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.groupBox2.Location = new System.Drawing.Point(22, 23);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(454, 111);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Pizzaria Restaurante";
            // 
            // btnSalao
            // 
            this.btnSalao.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.btnSalao.Location = new System.Drawing.Point(297, 48);
            this.btnSalao.Name = "btnSalao";
            this.btnSalao.Size = new System.Drawing.Size(125, 39);
            this.btnSalao.TabIndex = 2;
            this.btnSalao.Text = "Salão";
            this.btnSalao.UseVisualStyleBackColor = true;
            this.btnSalao.Click += new System.EventHandler(this.btnSalao_Click);
            // 
            // radPizzaria
            // 
            this.radPizzaria.AutoSize = true;
            this.radPizzaria.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.radPizzaria.Location = new System.Drawing.Point(24, 56);
            this.radPizzaria.Name = "radPizzaria";
            this.radPizzaria.Size = new System.Drawing.Size(82, 24);
            this.radPizzaria.TabIndex = 0;
            this.radPizzaria.TabStop = true;
            this.radPizzaria.Text = "Pizzaria";
            this.radPizzaria.UseVisualStyleBackColor = true;
            this.radPizzaria.CheckedChanged += new System.EventHandler(this.radPizzaria_CheckedChanged);
            // 
            // radRestaurante
            // 
            this.radRestaurante.AutoSize = true;
            this.radRestaurante.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.radRestaurante.Location = new System.Drawing.Point(128, 56);
            this.radRestaurante.Name = "radRestaurante";
            this.radRestaurante.Size = new System.Drawing.Size(116, 24);
            this.radRestaurante.TabIndex = 1;
            this.radRestaurante.TabStop = true;
            this.radRestaurante.Text = "Restaurante";
            this.radRestaurante.UseVisualStyleBackColor = true;
            this.radRestaurante.CheckedChanged += new System.EventHandler(this.radRestaurante_CheckedChanged);
            // 
            // frmModVendas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(488, 281);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmModVendas";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Módulo de vendas";
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lblSabor;
        private System.Windows.Forms.Button btnFazerEntrega;
        private System.Windows.Forms.RadioButton radPizzaria;
        private System.Windows.Forms.RadioButton radRestaurante;
        private System.Windows.Forms.TextBox txtTellCliente;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnSalao;
    }
}