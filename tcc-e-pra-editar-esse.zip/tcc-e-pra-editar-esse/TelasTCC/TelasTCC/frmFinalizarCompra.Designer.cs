﻿namespace TelasTCC
{
    partial class frmFinalizarCompra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbPizza = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radValeRefeicao = new System.Windows.Forms.RadioButton();
            this.radCredito = new System.Windows.Forms.RadioButton();
            this.radDebito = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.cbBandeira = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblTroco = new System.Windows.Forms.Label();
            this.txtValorEntregue = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnFinalizar = new System.Windows.Forms.Button();
            this.gbFinalizar = new System.Windows.Forms.GroupBox();
            this.btnEditar = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lblTelefone = new System.Windows.Forms.Label();
            this.lblEndereco = new System.Windows.Forms.Label();
            this.lblCliente = new System.Windows.Forms.Label();
            this.btnCorrigir = new System.Windows.Forms.Button();
            this.lblPrecoFinal = new System.Windows.Forms.Label();
            this.dgvPedidos = new System.Windows.Forms.DataGridView();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.brnEnviar = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lblPreco = new System.Windows.Forms.Label();
            this.lblId = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAddQuantidade = new System.Windows.Forms.TextBox();
            this.gbPizza.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.gbFinalizar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPedidos)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbPizza
            // 
            this.gbPizza.Controls.Add(this.groupBox1);
            this.gbPizza.Controls.Add(this.groupBox2);
            this.gbPizza.Controls.Add(this.btnFinalizar);
            this.gbPizza.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbPizza.Location = new System.Drawing.Point(12, 281);
            this.gbPizza.Name = "gbPizza";
            this.gbPizza.Size = new System.Drawing.Size(825, 161);
            this.gbPizza.TabIndex = 4;
            this.gbPizza.TabStop = false;
            this.gbPizza.Text = "Forma de pagamento";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radValeRefeicao);
            this.groupBox1.Controls.Add(this.radCredito);
            this.groupBox1.Controls.Add(this.radDebito);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.cbBandeira);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(29, 34);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(327, 110);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cartão";
            // 
            // radValeRefeicao
            // 
            this.radValeRefeicao.AutoSize = true;
            this.radValeRefeicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.radValeRefeicao.Location = new System.Drawing.Point(194, 24);
            this.radValeRefeicao.Name = "radValeRefeicao";
            this.radValeRefeicao.Size = new System.Drawing.Size(127, 24);
            this.radValeRefeicao.TabIndex = 23;
            this.radValeRefeicao.TabStop = true;
            this.radValeRefeicao.Text = "Vale Refeição";
            this.radValeRefeicao.UseVisualStyleBackColor = true;
            // 
            // radCredito
            // 
            this.radCredito.AutoSize = true;
            this.radCredito.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.radCredito.Location = new System.Drawing.Point(110, 24);
            this.radCredito.Name = "radCredito";
            this.radCredito.Size = new System.Drawing.Size(78, 24);
            this.radCredito.TabIndex = 22;
            this.radCredito.TabStop = true;
            this.radCredito.Text = "Crédito";
            this.radCredito.UseVisualStyleBackColor = true;
            // 
            // radDebito
            // 
            this.radDebito.AutoSize = true;
            this.radDebito.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.radDebito.Location = new System.Drawing.Point(27, 24);
            this.radDebito.Name = "radDebito";
            this.radDebito.Size = new System.Drawing.Size(74, 24);
            this.radDebito.TabIndex = 21;
            this.radDebito.TabStop = true;
            this.radDebito.Text = "Débito";
            this.radDebito.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(22, 68);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 20);
            this.label8.TabIndex = 20;
            this.label8.Text = "Bandeira";
            // 
            // cbBandeira
            // 
            this.cbBandeira.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cbBandeira.FormattingEnabled = true;
            this.cbBandeira.Items.AddRange(new object[] {
            "Master Card",
            "Extra",
            "..."});
            this.cbBandeira.Location = new System.Drawing.Point(110, 65);
            this.cbBandeira.Name = "cbBandeira";
            this.cbBandeira.Size = new System.Drawing.Size(206, 28);
            this.cbBandeira.TabIndex = 19;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblTroco);
            this.groupBox2.Controls.Add(this.txtValorEntregue);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(377, 34);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(265, 89);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Dinheiro";
            // 
            // lblTroco
            // 
            this.lblTroco.AutoSize = true;
            this.lblTroco.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTroco.Location = new System.Drawing.Point(91, 56);
            this.lblTroco.Name = "lblTroco";
            this.lblTroco.Size = new System.Drawing.Size(130, 20);
            this.lblTroco.TabIndex = 13;
            this.lblTroco.Text = "Troco:   R$ 00,00";
            // 
            // txtValorEntregue
            // 
            this.txtValorEntregue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtValorEntregue.Location = new System.Drawing.Point(150, 22);
            this.txtValorEntregue.Name = "txtValorEntregue";
            this.txtValorEntregue.Size = new System.Drawing.Size(79, 26);
            this.txtValorEntregue.TabIndex = 12;
            this.txtValorEntregue.TextChanged += new System.EventHandler(this.txtValorEntregue_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(26, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 20);
            this.label1.TabIndex = 11;
            this.label1.Text = "Valor entregue:";
            // 
            // btnFinalizar
            // 
            this.btnFinalizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinalizar.Location = new System.Drawing.Point(681, 59);
            this.btnFinalizar.Name = "btnFinalizar";
            this.btnFinalizar.Size = new System.Drawing.Size(109, 34);
            this.btnFinalizar.TabIndex = 5;
            this.btnFinalizar.Text = "Finalizar";
            this.btnFinalizar.UseVisualStyleBackColor = true;
            this.btnFinalizar.Click += new System.EventHandler(this.btnFinalizar_Click);
            // 
            // gbFinalizar
            // 
            this.gbFinalizar.Controls.Add(this.btnEditar);
            this.gbFinalizar.Controls.Add(this.label3);
            this.gbFinalizar.Controls.Add(this.lblTelefone);
            this.gbFinalizar.Controls.Add(this.lblEndereco);
            this.gbFinalizar.Controls.Add(this.lblCliente);
            this.gbFinalizar.Controls.Add(this.btnCorrigir);
            this.gbFinalizar.Controls.Add(this.lblPrecoFinal);
            this.gbFinalizar.Controls.Add(this.dgvPedidos);
            this.gbFinalizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.gbFinalizar.Location = new System.Drawing.Point(12, 25);
            this.gbFinalizar.Name = "gbFinalizar";
            this.gbFinalizar.Size = new System.Drawing.Size(825, 238);
            this.gbFinalizar.TabIndex = 3;
            this.gbFinalizar.TabStop = false;
            this.gbFinalizar.Text = "Pedido";
            // 
            // btnEditar
            // 
            this.btnEditar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditar.Location = new System.Drawing.Point(705, 158);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(105, 34);
            this.btnEditar.TabIndex = 17;
            this.btnEditar.Text = "Editar";
            this.btnEditar.UseVisualStyleBackColor = true;
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 25);
            this.label3.TabIndex = 15;
            this.label3.Text = "Pedido";
            // 
            // lblTelefone
            // 
            this.lblTelefone.AutoSize = true;
            this.lblTelefone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelefone.Location = new System.Drawing.Point(584, 116);
            this.lblTelefone.Name = "lblTelefone";
            this.lblTelefone.Size = new System.Drawing.Size(71, 20);
            this.lblTelefone.TabIndex = 14;
            this.lblTelefone.Text = "Telefone";
            // 
            // lblEndereco
            // 
            this.lblEndereco.AutoSize = true;
            this.lblEndereco.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEndereco.Location = new System.Drawing.Point(584, 79);
            this.lblEndereco.Name = "lblEndereco";
            this.lblEndereco.Size = new System.Drawing.Size(78, 20);
            this.lblEndereco.TabIndex = 13;
            this.lblEndereco.Text = "Endereço";
            // 
            // lblCliente
            // 
            this.lblCliente.AutoSize = true;
            this.lblCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCliente.Location = new System.Drawing.Point(584, 42);
            this.lblCliente.Name = "lblCliente";
            this.lblCliente.Size = new System.Drawing.Size(58, 20);
            this.lblCliente.TabIndex = 12;
            this.lblCliente.Text = "Cliente";
            // 
            // btnCorrigir
            // 
            this.btnCorrigir.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCorrigir.Location = new System.Drawing.Point(584, 158);
            this.btnCorrigir.Name = "btnCorrigir";
            this.btnCorrigir.Size = new System.Drawing.Size(105, 34);
            this.btnCorrigir.TabIndex = 11;
            this.btnCorrigir.Text = "Corrigir";
            this.btnCorrigir.UseVisualStyleBackColor = true;
            this.btnCorrigir.Click += new System.EventHandler(this.btnCorrigir_Click);
            // 
            // lblPrecoFinal
            // 
            this.lblPrecoFinal.AutoSize = true;
            this.lblPrecoFinal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecoFinal.Location = new System.Drawing.Point(31, 207);
            this.lblPrecoFinal.Name = "lblPrecoFinal";
            this.lblPrecoFinal.Size = new System.Drawing.Size(99, 20);
            this.lblPrecoFinal.TabIndex = 10;
            this.lblPrecoFinal.Text = "lblPrecoFinal";
            // 
            // dgvPedidos
            // 
            this.dgvPedidos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPedidos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column4,
            this.Column1,
            this.Column3,
            this.Column2});
            this.dgvPedidos.Location = new System.Drawing.Point(29, 42);
            this.dgvPedidos.Name = "dgvPedidos";
            this.dgvPedidos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPedidos.Size = new System.Drawing.Size(533, 150);
            this.dgvPedidos.TabIndex = 9;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "Id";
            this.Column4.HeaderText = "id";
            this.Column4.Name = "Column4";
            this.Column4.Visible = false;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "Item";
            this.Column1.HeaderText = "Itens";
            this.Column1.Name = "Column1";
            this.Column1.Width = 255;
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column3.DataPropertyName = "ItemQuantidade";
            this.Column3.HeaderText = "Quantidade";
            this.Column3.Name = "Column3";
            this.Column3.Width = 117;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.DataPropertyName = "ItemPreco";
            this.Column2.HeaderText = "Preço";
            this.Column2.Name = "Column2";
            // 
            // btnExcluir
            // 
            this.btnExcluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcluir.Location = new System.Drawing.Point(11, 45);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(105, 34);
            this.btnExcluir.TabIndex = 16;
            this.btnExcluir.Text = "Excluir";
            this.btnExcluir.UseVisualStyleBackColor = true;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox6);
            this.groupBox3.Controls.Add(this.groupBox5);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.groupBox3.Location = new System.Drawing.Point(860, 25);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(290, 319);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Edição";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnExcluir);
            this.groupBox6.Controls.Add(this.brnEnviar);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(18, 174);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(255, 125);
            this.groupBox6.TabIndex = 25;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Ações de edição";
            // 
            // brnEnviar
            // 
            this.brnEnviar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.brnEnviar.Location = new System.Drawing.Point(139, 45);
            this.brnEnviar.Name = "brnEnviar";
            this.brnEnviar.Size = new System.Drawing.Size(105, 34);
            this.brnEnviar.TabIndex = 18;
            this.brnEnviar.Text = "Enviar";
            this.brnEnviar.UseVisualStyleBackColor = true;
            this.brnEnviar.Click += new System.EventHandler(this.brnEnviar_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lblPreco);
            this.groupBox5.Controls.Add(this.lblId);
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.txtAddQuantidade);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(18, 42);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(255, 108);
            this.groupBox5.TabIndex = 24;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Atualizar Quantidade";
            // 
            // lblPreco
            // 
            this.lblPreco.AutoSize = true;
            this.lblPreco.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco.Location = new System.Drawing.Point(135, 74);
            this.lblPreco.Name = "lblPreco";
            this.lblPreco.Size = new System.Drawing.Size(49, 20);
            this.lblPreco.TabIndex = 20;
            this.lblPreco.Text = "preco";
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblId.Location = new System.Drawing.Point(24, 74);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(21, 20);
            this.lblId.TabIndex = 19;
            this.lblId.Text = "id";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 20);
            this.label2.TabIndex = 18;
            this.label2.Text = "Quantidade";
            // 
            // txtAddQuantidade
            // 
            this.txtAddQuantidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtAddQuantidade.Location = new System.Drawing.Point(115, 37);
            this.txtAddQuantidade.Name = "txtAddQuantidade";
            this.txtAddQuantidade.Size = new System.Drawing.Size(79, 26);
            this.txtAddQuantidade.TabIndex = 14;
            // 
            // frmFinalizarCompra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1162, 453);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.gbPizza);
            this.Controls.Add(this.gbFinalizar);
            this.Name = "frmFinalizarCompra";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Finalizar compra";
            this.gbPizza.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.gbFinalizar.ResumeLayout(false);
            this.gbFinalizar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPedidos)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbPizza;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbBandeira;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblTroco;
        private System.Windows.Forms.TextBox txtValorEntregue;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnFinalizar;
        private System.Windows.Forms.GroupBox gbFinalizar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblTelefone;
        private System.Windows.Forms.Label lblEndereco;
        private System.Windows.Forms.Label lblCliente;
        private System.Windows.Forms.Button btnCorrigir;
        private System.Windows.Forms.Label lblPrecoFinal;
        private System.Windows.Forms.DataGridView dgvPedidos;
        private System.Windows.Forms.RadioButton radValeRefeicao;
        private System.Windows.Forms.RadioButton radCredito;
        private System.Windows.Forms.RadioButton radDebito;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.Button btnExcluir;
        private System.Windows.Forms.Button btnEditar;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button brnEnviar;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAddQuantidade;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.Label lblPreco;
    }
}