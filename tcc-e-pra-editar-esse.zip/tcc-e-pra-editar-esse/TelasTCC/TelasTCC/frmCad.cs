﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Endereco;
using TelasTCC.DB.Usuario;

namespace TelasTCC
{
    public partial class frmCad : Form
    {
        public frmCad()
        {
            InitializeComponent();
        }
        string cpf,cp;
        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text == "" || txtUsuario.Text == "" || txtSenha.Text == "" || txtConfSenha.Text == "" || txtCell.Text == "" || txtCpf.Text == "" || txtSalario.Text == "" || txtFuncao.Text == "" || txtDataNascimento.Text == "" || txtRua.Text == "" || txtBairro.Text == "" || txtNumero.Text == "" || txtCep.Text == "")
            {
                MessageBox.Show("Preenchar todos os Campos", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                cp = txtCep.Text;
              
                cpf = txtCpf.Text;

                if (cpf.Length != 11)
                {
                    MessageBox.Show("CPF:" + cpf + " invalido");
                }
                else if (cp.Length != 8)
                {
                    MessageBox.Show("CEP:" + cp + " invalido");
                }
                
                else
                    {
                        if (txtSenha.Text.Equals(txtConfSenha.Text))
                        {

                            // Tabela de Endereco
                            EnderecoDTO dtoE = new EnderecoDTO();
                            dtoE.Bairro = txtBairro.Text;
                            dtoE.Cep = txtCep.Text;
                            dtoE.Complemento = txtComplemento.Text;
                            dtoE.Numero = txtNumero.Text;
                            dtoE.Rua = txtRua.Text;

                            EnderecoBusiness businessE = new EnderecoBusiness();
                            businessE.SalvarEndereco(dtoE);

                            // Tabela de Usuario
                            UsuarioDTO dto = new UsuarioDTO();
                            dto.Nome = txtNome.Text;
                            dto.Usuario = txtUsuario.Text;
                            dto.Senha = txtSenha.Text;
                            dto.ConfirmarSenha = txtConfSenha.Text;
                            dto.Celular = txtCell.Text;
                            dto.CPF = txtCpf.Text;
                            dto.Salario = txtSalario.Text;
                            dto.Funcao = txtFuncao.Text;
                            dto.DataNascimento = txtDataNascimento.Text;
                            dto.Situacao = ("Ativo");
                            UsuarioBusiness business = new UsuarioBusiness();
                            business.Salvar(dto);

                            // Messagem Final
                            MessageBox.Show("Usuário cadastrado.");
                            Form login = new frmLogin();
                            login.Show();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Senhas diferentes");
                            txtSenha.Text = "";
                            txtConfSenha.Text = "";
                            txtSenha.Focus();
                        }
                    }
                }
      

        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Digite somente letras");
                e.Handled = true;
            }
        }

        private void txtCell_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Digite somente números");
                e.Handled = true;
            }
        }

        private void txtCpf_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Digite somente números");
                e.Handled = true;
            }
        }

        private void txtSalario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Digite somente números");
                e.Handled = true;
            }
        }

        private void txtDataNascimento_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Digite somente números");
                e.Handled = true;
            }
        }

        private void txtCep_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Digite somente números");
                e.Handled = true;
            }
        }

        private void txtFuncao_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Digite somente letras");
                e.Handled = true;
            }

        }

        private void txtBairro_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Digite somente letras");
                e.Handled = true;
            }
        }

        private void txtRua_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Digite somente letras");
                e.Handled = true;
            }
        }
    }
        } 
    
    

