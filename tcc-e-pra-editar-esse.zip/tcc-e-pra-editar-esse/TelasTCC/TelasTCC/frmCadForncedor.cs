﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Fornecedores;

namespace TelasTCC
{
    public partial class frmCadFornecedor : Form
    {
        public frmCadFornecedor()
        {
            InitializeComponent();
        }

        static int Id;
        public void SetId(int id) {
            Id = id;
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            string cnpj = txtCnpj.Text;
            if (txtCnpj.Text == "" || txtFornecimento.Text == "" || txtNome.Text == "" || txtTelefone.Text == "")
            {
                MessageBox.Show("Preenchar todos os Campos", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (cnpj.Length != 14)
            {
                MessageBox.Show("O CNPJ: " + cnpj + " é invalido");
            }
            else
            {
                if (Id == 0)
                {
                    Cadastrar();
                }
                else if (Id == 1)
                {
                    Cadastrar();
                }
            }
        }

            public void Cadastrar()
            {
                FornecedoresDTO dto = new FornecedoresDTO();
                dto.Nome = txtNome.Text;
                dto.Fornecimento = txtFornecimento.Text;

                dto.Cnpj = txtCnpj.Text;
                dto.Telefone_um = txtTelefone.Text;
                dto.Telefone_dois = txtTelefoneDois.Text;

                if (dto.Telefone_um == string.Empty && dto.Telefone_dois == string.Empty)
                {
                    MessageBox.Show("Telefone é obrigatório.");
                    txtTelefone.Focus();
                }
                else
                {
                    if (dto.Telefone_um == string.Empty && dto.Telefone_dois != string.Empty)
                    {
                        dto.Telefone_um = dto.Telefone_dois;
                        dto.Telefone_dois = string.Empty;
                    }
                    FornecedoresBusiness business = new FornecedoresBusiness();
                    business.Salvar(dto);
                    MessageBox.Show("Fornecedor cadastrado.");
                }
            }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Digite somente letras");
                e.Handled = true;
            }
        }

        private void txtFornecimento_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Digite somente letras");
                e.Handled = true;
            }
        }

        private void txtCnpj_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Digite somente números");
                e.Handled = true;
            }
        }

        private void txtTelefone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Digite somente números");
                e.Handled = true;
            }
        }

        private void txtTelefoneDois_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Digite somente números");
                e.Handled = true;
            }
        }


        /* public void Atualizar()
         {
             FornecedoresDTO dto = new FornecedoresDTO();
             dto.Nome = txtNome.Text;
             dto.Fornecimento = txtFornecimento.Text;
             dto.TipoProduto = txtTipoProduto.Text;
             dto.Cnpj = txtCnpj.Text;
             dto.Telefone_um = txtTelefone.Text;
             dto.Telefone_dois = txtTelefoneDois.Text;

             FornecedoresBusiness business = new FornecedoresBusiness();
             business.Atualizar(dto);
             MessageBox.Show("Fornecedor atualizado.");
         }*/

    }
}