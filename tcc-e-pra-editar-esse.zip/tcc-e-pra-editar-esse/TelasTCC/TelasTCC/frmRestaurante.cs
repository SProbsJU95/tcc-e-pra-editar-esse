﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;  //apagar
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Restaurante;

namespace TelasTCC
{
    public partial class frmRestaurante : Form
    {
        public frmRestaurante()
        {
            InitializeComponent();
            cbRefeicao.DisplayMember = "tamanho";
            aux = 0;
        }
        int aux;

        static int entregaSalao = 0;
        public void setEntregaSalao(int entreSalao)
        { entregaSalao = entreSalao;}


        private void btnEnviar_Click(object sender, EventArgs e)
        {
            txtPeso.Visible = true;
            cbRefeicao.Visible = false;
            txtPeso.Left = 373; 
        }

        private void btnEnviarBebida_Click(object sender, EventArgs e)
        {
            RestauranteDTO dto = new RestauranteDTO();
            if (cbDose.Text != string.Empty){dto.Produto = cbDose.Text;}
            if (cbLata.Text != string.Empty) { dto.Produto = cbLata.Text; }
            if (cbSuco.Text != string.Empty) { dto.Produto = cbSuco.Text; }
            if (cb600ml.Text != string.Empty) { dto.Produto = cb600ml.Text; }
            if (cb2l.Text != string.Empty) { dto.Produto = cb2l.Text; }

            if (txtBebidadaQtde.Text != string.Empty){dto.QuantidadeProduto = txtBebidadaQtde.Text;}
            else{dto.QuantidadeProduto = "1";}

            RestauranteDatabase database = new RestauranteDatabase();
            dto.IdProduto = database.ListarProduto(dto.Produto);

            dto.Preco = database.ListarValor(dto.Produto);

            dto.idPedido = database.ListarPedido();
            
            RestauranteBusiness business = new RestauranteBusiness();
            business.Salvar(dto);
            MessageBox.Show("Bebida cadastrada.");

            aux++;
        }
        
        private void btnEnviarSobremesa_Click(object sender, EventArgs e)
        {
            RestauranteDTO dto = new RestauranteDTO();
            if (cbSorvete.Text != string.Empty) { dto.Produto = cbSorvete.Text; }
            if (cbDoce.Text != string.Empty) { dto.Produto = cbDoce.Text; }

            if (txtSobremesaQtde.Text!= string.Empty) { dto.QuantidadeProduto = txtSobremesaQtde.Text; }
            else { dto.QuantidadeProduto = "1"; }

            RestauranteDatabase database = new RestauranteDatabase();
            dto.IdProduto = database.ListarProduto(dto.Produto);

            dto.Preco = database.ListarValor(dto.Produto);

            dto.idPedido = database.ListarPedido();

            RestauranteBusiness business = new RestauranteBusiness();
            business.Salvar(dto);
            MessageBox.Show("Sobremesa cadastrada.");

            aux++;
        }

        private void btnEnviarTudo_Click(object sender, EventArgs e)
        {
            if (aux > 0) {
                RestauranteDTO dto = new RestauranteDTO();
                RestauranteDatabase database = new RestauranteDatabase();

                dto.idPedido = database.ListarPedido();
                dto.ValorFinal = database.ListarValorFinal(dto.idPedido);
                dto.TipoPedido = entregaSalao.ToString();

                RestauranteBusiness business = new RestauranteBusiness();
                business.SalvarPedido(dto);

                MessageBox.Show("Venda Finalizada!");

                Form finalizar = new frmFinalizarCompra();
                finalizar.Show();
                
                this.Close();
            }
            else
            {
                MessageBox.Show("Faça um pedido antes de finalizar a venda");
            }
        }

        private void radPeso_CheckedChanged(object sender, EventArgs e)
        {
            txtPeso.Visible = true;
            cbRefeicao.Visible = false;

            txtPeso.Focus();
        }

        private void radPratoFeito_CheckedChanged(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtPeso.Visible = false;
            cbRefeicao.Visible = true;

            RestauranteBusiness business = new RestauranteBusiness();

            DataTable lista = business.ListarPF(); cbRefeicao.DataSource = lista;
        }

        private void radFeijoada_CheckedChanged(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtPeso.Visible = false;
            cbRefeicao.Visible = true;
            

            RestauranteBusiness business = new RestauranteBusiness();
            
            DataTable lista = business.ListarRefeicao(); cbRefeicao.DataSource = lista;
             
        }

        private void btnEnviarRefeicao_Click(object sender, EventArgs e)
        {
            RestauranteDTO dto = new RestauranteDTO();
            if(radFeijoada.Checked == false && radPeso.Checked == false && radPratoFeito.Checked == false)
            {
                MessageBox.Show("Selecione o tipo de pedido de refeição");
            }
            else if(radFeijoada.Checked == true || radPratoFeito.Checked == true)
            {
                if (radFeijoada.Checked == true){ dto.Produto = "Feijoada " +cbRefeicao.Text; }
                else if (radPratoFeito.Checked == true) { dto.Produto = cbRefeicao.Text; }

                dto.QuantidadeProduto = "1";

                RestauranteDatabase database = new RestauranteDatabase();
                dto.IdProduto = database.ListarProduto(dto.Produto);

                dto.Preco = database.ListarValor(dto.Produto);
                
                dto.idPedido = database.ListarPedido();
                
                RestauranteBusiness business = new RestauranteBusiness();
                business.Salvar(dto);
                MessageBox.Show("Refeição cadastrada.");

                aux++;
            }
            else if (radPeso.Checked == true)
            {
                dto.Produto = "Peso";

                dto.QuantidadeProduto = "1";

                RestauranteDatabase database = new RestauranteDatabase();
                dto.IdProduto = database.ListarProduto(dto.Produto);

                float pct = 8;

                try
                {
                    dto.Preco = (float.Parse(txtPeso.Text) * pct).ToString();
                    dto.Preco = (float.Parse(dto.Preco) / 100).ToString();
                    dto.Preco = (float.Parse(txtPeso.Text) - float.Parse(dto.Preco)).ToString();

                    dto.idPedido = database.ListarPedido();

                    RestauranteBusiness business = new RestauranteBusiness();
                    business.Salvar(dto);
                    MessageBox.Show("Refeição cadastrada.");

                    aux++;
                }
                catch (Exception)
                {
                    MessageBox.Show("O valor digitado para peso é invalido");
                    txtPeso.Clear();
                    txtPeso.Focus();
                }
            }
        }

        private void cbDose_Click(object sender, EventArgs e)
        {
            RestauranteBusiness business = new RestauranteBusiness();
            cbDose.DisplayMember = "nome";
            DataTable lista = business.Listar("Dose"); cbDose.DataSource = lista;

            //cbDose.DataSource = null;
            cbSuco.DataSource = null;
            cbLata.DataSource = null;
            cb600ml.DataSource = null;
            cb2l.DataSource = null;
        }
        
        private void cbSuco_Click(object sender, EventArgs e)
        {
            RestauranteBusiness business = new RestauranteBusiness();
            cbSuco.DisplayMember = "nome";
            DataTable lista = business.Listar("Suco"); cbSuco.DataSource = lista;

            cbDose.DataSource = null;
            cbDose.DataSource = null;
            //cbSuco.DataSource = null;
            cbLata.DataSource = null;
            cb600ml.DataSource = null;
            cb2l.DataSource = null;
        }

        private void cbLata_Click(object sender, EventArgs e)
        {
            RestauranteBusiness business = new RestauranteBusiness();
            cbLata.DisplayMember = "nome";
            DataTable lista = business.Listar("Lata"); cbLata.DataSource = lista;

            cbDose.DataSource = null;
            cbDose.DataSource = null;
            cbSuco.DataSource = null;
            //cbLata.DataSource = null;
            cb600ml.DataSource = null;
            cb2l.DataSource = null;
        }

        private void cb600ml_Click(object sender, EventArgs e)
        {
            RestauranteBusiness business = new RestauranteBusiness();
            cb600ml.DisplayMember = "nome";
            DataTable lista = business.Listar("600ml"); cb600ml.DataSource = lista;

            cbDose.DataSource = null;
            cbDose.DataSource = null;
            cbSuco.DataSource = null;
            cbLata.DataSource = null;
            //cb600ml.DataSource = null;
            cb2l.DataSource = null;
        }

        private void cb2l_Click(object sender, EventArgs e)
        {
            RestauranteBusiness business = new RestauranteBusiness();
            cb2l.DisplayMember = "nome";
            DataTable lista = business.Listar("Refrigerante 2L"); cb2l.DataSource = lista;

            cbDose.DataSource = null;
            cbDose.DataSource = null;
            cbSuco.DataSource = null;
            cbLata.DataSource = null;
            cb600ml.DataSource = null;
            //cb2l.DataSource = null;
        }
        
        private void cbSorvete_Click(object sender, EventArgs e)
        {
            RestauranteBusiness business = new RestauranteBusiness();
            cbSorvete.DisplayMember = "nome";
            
            DataTable lista = business.Listar("Sorvete"); cbSorvete.DataSource = lista;

            cbDoce.DataSource = null;
            //cbSorvete.DataSource = null;
        }

        private void cbDoce_Click(object sender, EventArgs e)
        {
            RestauranteBusiness business = new RestauranteBusiness();
            cbDoce.DisplayMember = "nome";

            DataTable lista = business.Listar("Doce"); cbDoce.DataSource = lista;

            //cbDoce.DataSource = null;
            cbSorvete.DataSource = null;
        }
    }
}
