﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Login;
using TelasTCC.DB.ModVenda;

namespace TelasTCC
{
    public partial class frmModVendas : Form
    {
        public frmModVendas()
        {
            InitializeComponent();
        }

        private string horario = "";

        private void setHorario(string hora)
        {
            this.horario = hora;
        }
        
        private void btnSalao_Click(object sender, EventArgs e)
        {
            if (this.horario == "Pizzaria")
            {
                Form pizza = new frmPizzaria();
                pizza.Show();
                frmPizzaria pizzari = new frmPizzaria();
                pizzari.setEntregaSalao(1);
                //this.Hide();
            }
            else if (this.horario == "Restaurante")
            {
                Form restaurante = new frmRestaurante();
                restaurante.Show();
                frmRestaurante restaurant = new frmRestaurante();
                restaurant.setEntregaSalao(1);
                //this.Hide();
            }
        }

        private void radPizzaria_CheckedChanged(object sender, EventArgs e)
        {
            this.setHorario("Pizzaria");
        }

        private void radRestaurante_CheckedChanged(object sender, EventArgs e)
        {
            this.setHorario("Restaurante");
        }

        private void txtTellCliente_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void btnFazerEntrega_Click(object sender, EventArgs e)
        {
            if (txtTellCliente.Text != string.Empty)
            {
                ModVendaDatabase database = new ModVendaDatabase();
                string telefone = database.ListarTelefone(txtTellCliente.Text);

                if (telefone != "Telefone não encontrado.")
                {
                    Funcao funcao = new Funcao();
                    funcao.SetTellCliente(telefone);

                    if(this.horario == "Pizzaria")
                    {
                        Form pizzaria = new frmPizzaria();
                        pizzaria.Show();

                        this.Close();
                    }
                    else if(this.horario == "Restaurante")
                    {
                        Form restaurante = new frmRestaurante();
                        restaurante.Show();

                        this.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Telefone não encontrado");
                    txtTellCliente.Focus();
                }
            }
            else
            {
                MessageBox.Show("Selecione o telefone para entrega.");
            }
        }
    }
}
