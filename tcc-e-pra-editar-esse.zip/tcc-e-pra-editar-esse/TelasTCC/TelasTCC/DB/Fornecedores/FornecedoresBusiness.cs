﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TelasTCC.DB.Fornecedores
{
    class FornecedoresBusiness
    {
        public int Salvar(FornecedoresDTO dto)
        {
            if (dto.Nome == string.Empty)
                throw new ArgumentException("Nome é obrigatório.");

            if (dto.Fornecimento == string.Empty)
                throw new ArgumentException("Telefone é obrigatório.");

            if (dto.Cnpj == string.Empty)
                throw new ArgumentException("Telefone é obrigatório.");

            
            FornecedoresDatabase db = new FornecedoresDatabase();
            return db.Salvar(dto);
        }

        public List<FornecedoresDTO> Listar()
        {
            FornecedoresDatabase db = new FornecedoresDatabase();
            return db.Listar();
        }

        public int Atualizar( string cnpj ,FornecedoresDTO dto)
        {
            if (dto.Nome == string.Empty)
                throw new ArgumentException("Nome é obrigatório.");

            if (dto.Fornecimento == string.Empty)
                throw new ArgumentException("Fornecimento é obrigatório.");

            if (dto.Cnpj == string.Empty)
                throw new ArgumentException("CNPJ é obrigatório.");

            if (dto.Telefone_um == string.Empty) {
                throw new ArgumentException("Telefone Um é obrigatorio");

            }
            FornecedoresDatabase db = new FornecedoresDatabase();
            return db.Atualizar(cnpj, dto);
        }

    }
}
