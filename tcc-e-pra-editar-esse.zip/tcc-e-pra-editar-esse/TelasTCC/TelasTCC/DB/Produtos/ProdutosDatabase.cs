﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Base;

namespace TelasTCC.DB.Produtos
{
    class ProdutosDatabase
    {
        public int Salvar(ProdutosDTO dto)
        {
            // testar a possibilidade de erro



            string script = @"insert into produto (Nome, Valor, Descricao) values (@Nome, @Valor,@Descricao)";

            List<MySqlParameter> parms = new List<MySqlParameter>();
            parms.Add(new MySqlParameter("Nome", dto.Nome));
            parms.Add(new MySqlParameter("Valor", dto.Valor));
            parms.Add(new MySqlParameter("Descricao", dto.Descricao));
           

            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }
        
      

        public int Alterar(ProdutosDTO dto)
        {        
            string script = @"update produto set nome = @nome,valor=@valor, descricao=@descricao where `idProduto`=" + dto.IdProduto ;

            //update produto set nome = 'valter',valor=25.6, descricao='suco' where idProduto=1
            List<MySqlParameter> parms = new List<MySqlParameter>();

            parms.Add(new MySqlParameter("nome", dto.Nome));
            parms.Add(new MySqlParameter("valor", dto.Valor));
            parms.Add(new MySqlParameter("descricao", dto.Descricao));
            parms.Add(new MySqlParameter("idProduto", dto.IdProduto));

            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }

        public List<ProdutosDTO> Listarprodutos()
        {

            string script = "SELECT idProduto,nome,valor,descricao from produto";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<ProdutosDTO> lista = new List<ProdutosDTO>();

            while (reader.Read())
            {
                ProdutosDTO dto = new ProdutosDTO();
                dto.IdProduto = reader.GetString("idProduto");
                dto.Nome = reader.GetString("nome");
                dto.Valor = reader.GetString("valor");
                dto.Descricao = reader.GetString("descricao");
               

                lista.Add(dto);
            }
            reader.Close();

            return lista;
        }
        public int Excluir(string id)
        {
            string script = @"DELETE FROM produto WHERE `idProduto` = " + id;

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }
    }
}

